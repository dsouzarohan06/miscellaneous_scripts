use YCSB
db.usertable.remove({})
