use BenchTest;
DELETE FROM usertable;
